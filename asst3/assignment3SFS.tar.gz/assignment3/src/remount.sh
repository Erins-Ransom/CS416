#!/bin/bash

while getopts ":c:" opt; do
	case ${opt} in
		c )
			fusermount -u /tmp/erk58/mountdir
			rm /.freespace/erk58/testfile
			touch /.freespace/erk58/testfile
			./sfs /.freespace/erk58/testfile /tmp/erk58/mountdir
			;;
	esac
done

while getopts ":m:" opt; do
	case ${opt} in 
		m )
			fusermount -u /tmp/erk58/mountdir
			make
			rm /.freespace/erk58/testfile
			touch /.freespace/erk58/testfile
			./sfs /.freespace/erk58/testfile /tmp/erk58/mountdir
			;;
	esac
done

